package com.shop.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PaymentDAO {
	private Connection con = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	//결제 내역 목록 - ArrayList<PaymentVO> :  getPaymentList(회원아이디) - getPaymentList()
	//결제 상세 내역 - PaymentVO : getPayment(장바구니아이디, 회원아이디) - getPayment(장바구니아이디)
	//결제 수정 - int : updatePayment(장바구니아이디, 회원아이디) - updatePayment(장바구니아이디, 회원아이디)
	//결제 삭제(취소) - int : deletePayment(장바구니아이디)
			//삭제 원인 - 회원이 결제 취소(단, 배송 전만 가능)
	//결제 추가 - int : addPayment(PaymentVO)
			//추가 원인 - 회원이 장바구니에서 결제, 구매하기에서 결제에서 결제
}
