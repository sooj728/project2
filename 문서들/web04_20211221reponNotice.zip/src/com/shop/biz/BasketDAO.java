package com.shop.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BasketDAO {
	private Connection con = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	//장바구니 내역 목록 - ArrayList<BasketVO> :  getBasketList(회원아이디) - getBasketList()
	//장바구니 상세 내역 - BasketVO : getBasket(장바구니아이디, 회원아이디) - getBasket(장바구니아이디)
	//장바구니 수정 - int : updateBasket(장바구니아이디, 회원아이디) - updateBasket(장바구니아이디, 회원아이디)
	//장바구니 삭제(취소) - int : deleteBasket(장바구니아이디)
			//삭제 원인 - 회원이 삭제, 결제를 완료
	//장바구니 추가 - int : addBasket(BasketVO)
			//추가 원인 - 회원이 추가, 구매하기에서 결제를 하지 않은 경우
}
